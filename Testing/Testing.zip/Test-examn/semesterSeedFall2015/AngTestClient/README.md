# angular-seed — A seed for AngularJS apps

This seed is made for computer science classes at https://www.cphbusiness.dk
It is NOT meant for production.

## Contact
Lars Mortensen lam@cphbuisiness.dk

[git]: http://git-scm.com/
[bower]: http://bower.io
[npm]: https://www.npmjs.org/
[node]: http://nodejs.org
[protractor]: https://github.com/angular/protractor
[jasmine]: http://jasmine.github.io
[karma]: http://karma-runner.github.io
[travis]: https://travis-ci.org/
[http-server]: https://github.com/nodeapps/http-server

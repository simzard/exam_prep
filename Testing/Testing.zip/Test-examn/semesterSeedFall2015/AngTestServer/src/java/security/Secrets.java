package security;

/*
You should add your own secret strings in here
*/
public class Secrets {
  
  public final static String ADMIN = "aM98954hgsaj7vkd8e4ksdutiahgjhgagiplx";
  public final static String USER =  "jghjdk8546lbgjd5HGdrterhgHYg65JDSU5TU";
  
}

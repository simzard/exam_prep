# Test examn

This seed is meant only as a starting point for test examn.

It is not reviewed for, and definitely not recommended for, real-life projects.

sal@cphbusiness.dk
